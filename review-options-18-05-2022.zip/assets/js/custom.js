jQuery(document).ready(function() {
    console.log("ready!");
    jQuery('.alert-dismissable').delay(3000).fadeOut("slow");
});